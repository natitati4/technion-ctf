#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void secret_ritual() {
    char scroll[64];
    puts("The Oracle awaits your chant:");
    gets(scroll);
}

void ask_oracle() {
    printf("The Oracle whispers: 'puts=%p'\n", puts);  // libc leak
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);

    puts("You are a brave adventurer.");
    puts("You may ask the Oracle *one* question.");
    ask_oracle();

    puts("The Oracle fades into smoke...");
    puts("You must now perform the ritual alone.");
    secret_ritual();

    return 0;
}
