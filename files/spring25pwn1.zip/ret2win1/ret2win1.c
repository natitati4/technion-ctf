#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

void win() {
    char flag[100];
    int fd = open("flag.txt", O_RDONLY);
    read(fd, flag, sizeof(flag) - 1);
    flag[99] = '\0';
    puts(flag);
    close(fd);
    exit(0);
}

void process_command() {
    char cmd[64];
    puts("Enter command:");
    read(0, cmd, 0x64);
    printf("Processing command: %s\n", cmd);
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    puts("=== Welcome to Account Manager 2000 ===");
    process_command();
    puts("Done.");
    return 0;
}
