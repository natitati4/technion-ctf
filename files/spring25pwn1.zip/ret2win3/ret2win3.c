#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

void win() {
    char flag[100];
    int fd = open("flag.txt", O_RDONLY);
    if (fd < 0) { puts("open flag failed. Tell admin."); exit(1); }
    read(fd, flag, sizeof(flag) - 1);
    flag[99] = '\0';
    puts(flag);
    close(fd);
    exit(0);
}

void welcome_user() {
    char name[0x28];
    puts("Welcome! Please enter your name:");
    unsigned int nread = read(0, name, 0x28);
    name[nread] = '\n'; // For nice printing :)
    printf("Hello %s let's get your feedback.\n", name); // I wonder what this leaks
    memset(name, 0, nread + 1); // Let's not forget to clean up!
}

void get_feedback() {
    char feedback[72];
    puts("Enter your feedback below:");
    read(0, feedback, 0x72);
    puts("Thanks for the feedback! We totally read it.");
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    puts("Welcome to the feedback program!");
    welcome_user();
    get_feedback();
    puts("Goodbye!");
    return 0;
}
