#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

__thread int A, B, C, D, E, F, G;

void init() {
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        puts("open flag failed. Tell admin.");
        exit(1);
    }
    read(fd, &A, 4);
    read(fd, &B, 4);
    read(fd, &C, 4);
    read(fd, &D, 4);
    read(fd, &E, 4);
    read(fd, &F, 4);
    read(fd, &G, 4);
    close(fd);
}

void _A() { puts("[A] You destroyed: Tom Riddle's Diary"); A = 0; }
void _B() { puts("[B] You destroyed: Marvolo Gaunt's Ring"); B = 0; }
void _C() { puts("[C] You destroyed: Helga Hufflepuff's Cup"); C = 0; }
void _D() { puts("[D] You destroyed: Salazar Slytherin's Locket"); D = 0; }
void _E() { puts("[E] You destroyed: Rowena Ravenclaw's Diadem"); E = 0; }
void _F() { puts("[F] You destroyed: Nagini the Snake"); F = 0; }
void _G() { puts("[G] You destroyed: Harry Potter"); G = 0; }


void check() {
    char flag[40];
    int fd = open("flag.txt", O_RDONLY);
    if (fd < 0) { puts("open flag failed. Tell admin."); exit(1); }
    read(fd, flag, sizeof(flag) - 1);
    flag[39] = '\0';
    puts("I hope you didn't cheat.......");
    ((int*)flag)[0] ^= A;
    ((int*)flag)[1] ^= B;
    ((int*)flag)[2] ^= C;
    ((int*)flag)[3] ^= D;
    ((int*)flag)[4] ^= E;
    ((int*)flag)[5] ^= F;
    ((int*)flag)[6] ^= G;
    puts(flag);
    close(fd);
    exit(0);
}

void magic() {
    char buf[0x20];
    puts("Voldemort concealed his splitted soul inside 7 horcruxes.");
    puts("Find and destroy them all: ");
    puts("(Totally not stolen from pwnable.kr)");
    read(0, buf, 0x68);
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    init();
    magic();
    return 0;
}
