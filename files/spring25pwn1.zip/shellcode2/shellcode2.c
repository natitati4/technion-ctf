#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

void geronimo() {
    char buf[0x200];

    puts("Give me your best shot:");
    ssize_t len = read(0, buf, sizeof(buf));

    int offset = rand() % 100;
    puts("I trust u with my eyes closed. Geronimo!");
    // jump into the buffer at unknown offset, making your shellcode unreliable
    ((void(*)())(buf + offset))();
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    srand(time(NULL));
    geronimo();
    return 0;
}
