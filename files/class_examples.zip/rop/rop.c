#include <stdio.h>

int blockade = 1;

void flag(int check) {
    if (blockade) {
        puts("You are not allowed to call this function!");
        return;
    }
    if(check == 0xdeadc0de) {
        puts("flag{secret_flag_that_is_different_on_remote}");
    }
}

void unblock() {
    blockade = 0;
}

void vuln() {
    char buffer[100];
    puts("Wisdom goes here:");
    read(0, buffer, 0x100);
}

int main() {
    vuln();
}