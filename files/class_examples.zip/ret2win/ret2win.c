#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

char *gets(char *s);

void win() {
    int fd = open("flag.txt", O_RDONLY);
    if (fd < 0) {
        write(1, "Failed to open flag.txt\n", 25);
        exit(1);
    }
    char flag[100];
    ssize_t n = read(fd, flag, sizeof(flag) - 1);
    if (n < 0) {
        write(1, "Failed to read flag\n", 20);
        exit(1);
    }
    flag[n] = '\0';
    write(1, flag, n);
    close(fd);
    exit(0);
}

void vuln() {
    char buf[32];
    puts("Tell me something:");
    gets(buf);
}

int main() {
    vuln();
    return 0;
}
